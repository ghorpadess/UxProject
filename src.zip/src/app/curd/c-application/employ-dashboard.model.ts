export class EmpployeeModel {
    id: number = 0;
    firstName: string = '';
    lastName: string = '';
    email: string = '';
    mobile: any = '';
    Salary: string = '';
}